define({

    font: 'Arial, Helvetica, sans-serif',
    undefinedTextReturnValue: 'undefined key',
    visu: {
        activityCount: false
    },
    ContentCaching: {
        preserveOldValues: true
    },
    themeFolder: 'release/'
});
